class RobotRun1:
    def __init__(self, myPrimeHub):
        self._myPrimeHub = myPrimeHub

    def doit(self):
        return 9;

