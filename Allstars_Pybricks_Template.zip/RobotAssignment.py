class RobotAssignment:
    def __init__(self):
        self.data = []

